package upeu.edu.pe.authservice.msvcauthservice.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import upeu.edu.pe.authservice.msvcauthservice.entity.dto.TokenEntity;

import java.util.Optional;

public interface TokenRepository extends JpaRepository<TokenEntity, Long> {
    Optional<TokenEntity> findByCorreo(String correo);
}