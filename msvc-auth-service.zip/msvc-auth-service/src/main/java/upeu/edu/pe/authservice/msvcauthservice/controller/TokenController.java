package upeu.edu.pe.authservice.msvcauthservice.controller;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import upeu.edu.pe.authservice.msvcauthservice.entity.dto.TokenEntity;
import upeu.edu.pe.authservice.msvcauthservice.repository.TokenRepository;

import java.util.Optional;

@RestController
@RequestMapping("/auth/tokens")
public class TokenController {

    private static final String REFRESH_SECRET_KEY = "mi-clave-secreta-refresh";

    @Autowired
    private TokenRepository tokenRepository;

    @GetMapping("/por-correo")
    public ResponseEntity<?> obtenerTokenPorCorreo(@RequestParam String correo) {
        Optional<TokenEntity> tokenOpt = tokenRepository.findByCorreo(correo);

        if (tokenOpt.isPresent()) {
            return ResponseEntity.ok(tokenOpt.get().getToken());
        } else {
            return ResponseEntity.status(404).body("Token no encontrado para el correo: " + correo);
        }
    }

    @DeleteMapping("/revocar")
    public ResponseEntity<?> revocarTokenPorCorreo(@RequestParam String correo) {
        Optional<TokenEntity> tokenOpt = tokenRepository.findByCorreo(correo);

        if (tokenOpt.isPresent()) {
            tokenRepository.delete(tokenOpt.get());
            return ResponseEntity.ok("🔒 Token revocado correctamente para: " + correo);
        } else {
            return ResponseEntity.status(404).body("❌ No se encontró token para revocar con el correo: " + correo);
        }
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refreshToken(@RequestParam String refreshToken) {
        // Verificar si el refresh token es válido
        try {
            String correo = JWT.require(Algorithm.HMAC256(REFRESH_SECRET_KEY))
                    .build()
                    .verify(refreshToken)
                    .getSubject();

            // Verificar si existe el refresh token en la base de datos
            Optional<TokenEntity> tokenOpt = tokenRepository.findByCorreo(correo);
            if (tokenOpt.isPresent() && tokenOpt.get().getRefreshToken().equals(refreshToken)) {
                // Si el refresh token es válido, generar un nuevo access token
                String newAccessToken = generarNuevoAccessToken(correo);

                return ResponseEntity.ok(new AuthResponse(newAccessToken));
            } else {
                return ResponseEntity.status(400).body("Invalid refresh token");
            }
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Invalid refresh token");
        }
    }

    private String generarNuevoAccessToken(String correo) {
        // Lógica para generar un nuevo access token
        return JWT.create()
                .withSubject(correo)
                .withIssuedAt(new java.util.Date())
                .withExpiresAt(new java.util.Date(System.currentTimeMillis() + 86400000)) // 1 día
                .sign(Algorithm.HMAC256("mi-clave-secreta"));
    }

    // Clase interna para la respuesta del token
    public static class AuthResponse {
        private String accessToken;

        public AuthResponse(String accessToken) {
            this.accessToken = accessToken;
        }

        public String getAccessToken() {
            return accessToken;
        }

        public void setAccessToken(String accessToken) {
            this.accessToken = accessToken;
        }
    }
}