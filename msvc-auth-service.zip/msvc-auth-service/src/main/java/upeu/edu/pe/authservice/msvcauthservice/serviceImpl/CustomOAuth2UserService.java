package upeu.edu.pe.authservice.msvcauthservice.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import upeu.edu.pe.authservice.msvcauthservice.config.TokenService;
import upeu.edu.pe.authservice.msvcauthservice.entity.dto.UserDTO;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
public class CustomOAuth2UserService extends DefaultOAuth2UserService {

    private static final String EXTERNAL_MICROSERVICE_URL = "http://localhost:8082/api/usuarios";

    @Autowired
    private RestTemplate restTemplate; // Inyección de RestTemplate

    @Autowired
    private PasswordEncoder passwordEncoder; // Inyección de PasswordEncoder

    @Autowired
    private TokenService tokenService; // Inyección de TokenService

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) {
        OAuth2User oAuth2User = super.loadUser(userRequest);
        Map<String, Object> attributes = oAuth2User.getAttributes();

        String registrationId = userRequest.getClientRegistration().getRegistrationId();

        System.out.println("🔎 Login con proveedor: " + registrationId);
        System.out.println("Attributes recibidos: " + attributes);

        String correo = null;
        String nombre = null;
        String apellido = null;
        String foto = null;
        String tipoUsuario = null;

        if ("google".equals(registrationId)) {
            // 🌐 Google
            correo = (String) attributes.get("email");
            nombre = (String) attributes.get("given_name");
            apellido = (String) attributes.get("family_name");
            foto = (String) attributes.get("picture");

            if (correo == null) correo = (String) attributes.get("sub") + "@google.com";
            if (nombre == null) nombre = (String) attributes.get("name");
            if (apellido == null) apellido = "";
            if (foto == null) foto = "";

            tipoUsuario = "GOOGLE_USER";

        } else if ("github".equals(registrationId)) {
            // 🐱 GitHub
            String accessToken = userRequest.getAccessToken().getTokenValue();
            correo = fetchPrimaryEmailFromGitHub(accessToken);

            nombre = (String) attributes.get("name"); // GitHub devuelve "name"
            if (nombre == null || nombre.isEmpty()) {
                nombre = (String) attributes.get("login"); // fallback al username
            }

            apellido = ""; // GitHub no tiene apellido
            foto = (String) attributes.get("avatar_url");
            tipoUsuario = "GITHUB_USER";
        }

        // ✅ Registrar el usuario (sea Google o GitHub)
        registrarUsuario(correo, nombre, apellido, foto, tipoUsuario);
        verificarYAutenticarUsuario(correo, tipoUsuario);
        return oAuth2User;
    }

    private void verificarYAutenticarUsuario(String correo, String tipoUsuario) {
        // 1. Llamar a /api/usuarios/buscar-por-correo para obtener el usuario
        ResponseEntity<UserDTO> response = restTemplate.exchange(
                "http://localhost:8082/api/usuarios/buscar-por-correo?correo=" + correo,
                HttpMethod.GET,
                null,
                UserDTO.class
        );

        if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
            throw new RuntimeException("❌ Usuario no encontrado.");
        }

        UserDTO usuario = response.getBody();

        // 2. Verificar la contraseña desencriptada
        if (!verificarContraseña(tipoUsuario, usuario.getPassword())) {
            throw new RuntimeException("❌ Contraseña inválida.");
        }

        // 3. Generar y guardar el token
        UserDTO.RolDTO rolDTO = new UserDTO.RolDTO(usuario.getRol().getId());
        UserDTO.ProfileDTO profileDTO = new UserDTO.ProfileDTO(usuario.getProfile().getNombre(),
                usuario.getProfile().getApellido(),
                usuario.getProfile().getAvatar_url(),
                usuario.getProfile().getPais(),
                usuario.getProfile().getCelular());
        UserDTO userDTO = new UserDTO(
                usuario.getFirstName(),
                usuario.getLastName(),
                usuario.getRoles(),
                LocalDate.now(),
                usuario.getCorreo(),
                usuario.getCorreo(),
                "USER",
                'A',
                rolDTO,
                profileDTO
        );
        // Llamamos al servicio de generación de token
        String token = tokenService.generarYGuardarToken(userDTO);
        System.out.println("✅ Usuario autenticado, token generado: " + token);
    }

    private boolean verificarContraseña(String rawPassword, String hashedPassword) {
        // Verificamos la contraseña usando el PasswordEncoder de Spring
        return passwordEncoder.matches(rawPassword, hashedPassword);
    }


    private void registrarUsuario(String correo, String nombre, String apellido, String foto, String tipoUsuario) {
        UserDTO.RolDTO rolDTO = new UserDTO.RolDTO(1L);
        UserDTO.ProfileDTO profileDTO = new UserDTO.ProfileDTO(nombre, apellido, foto, "Perú", "000000000");
        UserDTO userDTO = new UserDTO(
                nombre,
                apellido,
                Collections.singleton("USER"),
                LocalDate.now(),
                correo,
                correo,
                tipoUsuario,
                'A',
                rolDTO,
                profileDTO
        );

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        HttpEntity<UserDTO> entity = new HttpEntity<>(userDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(EXTERNAL_MICROSERVICE_URL, HttpMethod.POST, entity, String.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            System.out.println("✅ Usuario registrado correctamente.");
        } else {
            throw new RuntimeException("❌ Error al registrar el usuario.");
        }
    }

    private String fetchPrimaryEmailFromGitHub(String accessToken) {
        String url = "https://api.github.com/user/emails";

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<List> response = restTemplate.exchange(
                url,
                HttpMethod.GET,
                entity,
                List.class
        );

        List<Map<String, Object>> emails = response.getBody();

        for (Map<String, Object> emailEntry : emails) {
            Boolean primary = (Boolean) emailEntry.get("primary");
            Boolean verified = (Boolean) emailEntry.get("verified");
            if (Boolean.TRUE.equals(primary) && Boolean.TRUE.equals(verified)) {
                return (String) emailEntry.get("email");
            }
        }

        // Si no encuentra ninguno, devuelve null (puedes poner un fallback si quieres)
        return null;
    }
}
