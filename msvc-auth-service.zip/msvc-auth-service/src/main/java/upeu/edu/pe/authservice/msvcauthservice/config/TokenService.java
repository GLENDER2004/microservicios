package upeu.edu.pe.authservice.msvcauthservice.config;


import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upeu.edu.pe.authservice.msvcauthservice.entity.dto.TokenEntity;
import upeu.edu.pe.authservice.msvcauthservice.entity.dto.UserDTO;
import upeu.edu.pe.authservice.msvcauthservice.repository.TokenRepository;

import java.util.Date;

@Service
public class TokenService {

    @Autowired
    private TokenRepository tokenRepository;

    private static final String ACCESS_SECRET_KEY = "mi-clave-secreta"; // Clave secreta para el token de acceso
    private static final String REFRESH_SECRET_KEY = "mi-clave-secreta-refresh"; // Clave secreta para el refresh token

    public String generarYGuardarToken(UserDTO usuario) {
        // Generación del Access Token
        String accessToken = JWT.create()
                .withSubject(usuario.getCorreo())
                .withClaim("usuario", usuario.getUsuario())
                .withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis() + 86400000)) // 1 día de expiración
                .sign(Algorithm.HMAC256(ACCESS_SECRET_KEY));

        // Generación del Refresh Token
        String refreshToken = JWT.create()
                .withSubject(usuario.getCorreo())
                .withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis() + 2592000000L)) // 30 días de expiración
                .sign(Algorithm.HMAC256(REFRESH_SECRET_KEY));

        // Guardar el Refresh Token en la base de datos
        TokenEntity tokenEntity = new TokenEntity(usuario.getCorreo(), accessToken, refreshToken);
        tokenRepository.save(tokenEntity);

        return accessToken;  // Retorna solo el access token para el cliente
    }
}