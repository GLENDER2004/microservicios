package upeu.edu.pe.authservice.msvcauthservice.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/usuarios")
public class GoogleController {

    @GetMapping("/user")
    public Object user(@AuthenticationPrincipal OAuth2User user) {
        if (user == null) {
            throw new RuntimeException("No se ha encontrado un usuario autenticado.");
        }
        return user.getAttributes();



    }

}
