package upeu.edu.pe.authservice.msvcauthservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcAuthServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsvcAuthServiceApplication.class, args);
    }

}
