package upeu.edu.pe.authservice.msvcauthservice.service;


import org.keycloak.representations.idm.UserRepresentation;
import upeu.edu.pe.authservice.msvcauthservice.entity.dto.UserDTO;

import java.util.List;

public interface IKeycloakService {

    List<UserRepresentation> findAllUsers();
    List<UserRepresentation> searchUserByUsuario(String usuario);
    String createUser(UserDTO userDTO);
    void deleteUser(String userId);
    void updateUser(String userId, UserDTO userDTO);
}