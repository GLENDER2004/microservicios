package upeu.edu.pe.authservice.msvcauthservice.entity.dto;

import java.time.LocalDate;
import java.util.Set;

public class UserDTO {

    private String firstName;
    private String lastName;
    private Set<String> roles;
    private LocalDate fechaRegistro;
    private String correo;
    private String usuario;
    private String password;
    private char estado;
    private RolDTO rol; // Cambiar id_rol por rol como un objeto
    private ProfileDTO profile; // Añadir un campo para profile

    public UserDTO(String firstName, String lastName, Set<String> roles, LocalDate fechaRegistro, String correo, String usuario, String password, char estado, RolDTO rol, ProfileDTO profile) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.roles = roles;
        this.fechaRegistro = fechaRegistro;
        this.correo = correo;
        this.usuario = usuario;
        this.password = password;
        this.estado = estado;
        this.rol = rol;
        this.profile = profile;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Set<String> getRoles() {
        return roles;
    }

    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public char getEstado() {
        return estado;
    }

    public void setEstado(char estado) {
        this.estado = estado;
    }

    public RolDTO getRol() {
        return rol;
    }

    public void setRol(RolDTO rol) {
        this.rol = rol;
    }

    public ProfileDTO getProfile() {
        return profile;
    }

    public void setProfile(ProfileDTO profile) {
        this.profile = profile;
    }

    // Clase interna RolDTO
    public static class RolDTO {
        private Long id;

        public RolDTO(Long id) {
            this.id = id;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }
    }

    // Clase interna ProfileDTO
    public static class ProfileDTO {
        private String nombre;
        private String apellido;
        private String avatar_url;
        private String pais;
        private String celular;

        public ProfileDTO(String nombre, String apellido, String avatarUrl, String pais, String celular) {
            this.nombre = nombre;
            this.apellido = apellido;
            this.avatar_url = avatarUrl;
            this.pais = pais;
            this.celular = celular;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getApellido() {
            return apellido;
        }

        public void setApellido(String apellido) {
            this.apellido = apellido;
        }

        public String getAvatar_url() {
            return avatar_url;
        }

        public void setAvatar_url(String avatar_url) {
            this.avatar_url = avatar_url;
        }

        public String getPais() {
            return pais;
        }

        public void setPais(String pais) {
            this.pais = pais;
        }

        public String getCelular() {
            return celular;
        }

        public void setCelular(String celular) {
            this.celular = celular;
        }
    }
}
