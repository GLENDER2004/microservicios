package upeu.edu.pe.authservice.msvcauthservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcAuthServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
