package upeu.edu.pe.authservice.msvcauthservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/auth")

public class ControlarPassword {

    @Autowired
    private PasswordEncoder passwordEncoder;
    @PostMapping("/encrypt-password")
    public ResponseEntity<String> encryptPassword(@RequestBody Map<String, String> body) {
        String password = body.get("password");
        return ResponseEntity.ok(passwordEncoder.encode(password));
    }
}